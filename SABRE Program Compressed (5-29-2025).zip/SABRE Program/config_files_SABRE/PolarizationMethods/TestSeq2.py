import nidaqmx
import time
import numpy as np

with nidaqmx.Task() as task:
    task.ao_channels.add_ao_voltage_chan("Dev1/ao1", min_val=-10.0, max_val=10.0)  # Define range explicitly
    task.write(5)  # Set to 10V initially
    time.sleep(1)
    task.write(0)  # Send 0V
    print("10V output to oscilloscope.")
    
    # Can see if it works if the voltage on the Oscilloscope jumps then drops
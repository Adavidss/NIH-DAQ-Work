[
    {"ao_channel": 0, "voltage": 10, "duration": 5},
    {"ao_channel": 1, "voltage": 5, "duration": 5},
    {"ao_channel": 0, "voltage": 0, "duration": 3},
    {"ao_channel": 1, "voltage": 0, "duration": 3}
]
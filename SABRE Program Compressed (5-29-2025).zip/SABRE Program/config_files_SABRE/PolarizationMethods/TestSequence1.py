import nidaqmx
import time
import numpy as np

# Configuration
daq_channel = "Dev1/ao1"  # Change this to your actual device and channel
voltage_range = (-10.0, 10.0)  # Set according to DAQ and electromagnet driver limits
ramp_time = 5  # Time (seconds) to ramp between voltages
steps = 100  # Number of steps in the ramp

def set_magnetic_field(voltage):
    """Sets the output voltage to control the magnetic field."""
    with nidaqmx.Task() as task:
        task.ao_channels.add_ao_voltage_chan(daq_channel, min_val=voltage_range[0], max_val=voltage_range[1])
        task.write(voltage)
        print(f"Set voltage to {voltage}V")

def ramp_magnetic_field(start_voltage, end_voltage, duration=ramp_time, steps=steps):
    """Smoothly ramps the output voltage from start_voltage to end_voltage."""
    with nidaqmx.Task() as task:
        task.ao_channels.add_ao_voltage_chan(daq_channel, min_val=voltage_range[0], max_val=voltage_range[1])
        
        voltages = np.linspace(start_voltage, end_voltage, steps)
        dt = duration / steps

        for v in voltages:
            task.write(v)
            time.sleep(dt)  # Control ramp speed
            print(f"Voltage: {v:.3f}V")

# Example Usage:
if __name__ == "__main__":
    set_magnetic_field(0)  # Start with 0V
    time.sleep(2)

    print("Ramping up to 5V...")
    ramp_magnetic_field(0, 5)  # Ramp up to 5V

    time.sleep(2)

    print("Ramping down to -5V...")
    ramp_magnetic_field(5, -5)  # Ramp down to -5V

    time.sleep(2)

    print("Turning off field...")
    set_magnetic_field(0)  # Turn off field
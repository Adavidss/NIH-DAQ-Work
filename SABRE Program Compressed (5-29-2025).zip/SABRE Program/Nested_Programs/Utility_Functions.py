import json
import os
import sys

from Constants_Paths import (
    CONFIG_DIR,
    INITIAL_STATE
)

# ==== PURE UTILITY FUNCTIONS (no-GUI) =======================
def convert_value(value, unit, conversion_type="time"):
    """Universal value converter"""
    try:
        value = float(value)
        conversions = {
            "time": {"sec": 1, "min": 60, "ms": 0.001},
            "magnetic": {"T": 1, "mT": 1e-3, "µT": 1e-6},
            "pressure": {"psi": 1, "bar": 14.5038, "atm": 14.696},
            "temperature": {
                "K": lambda x: x,
                "C": lambda x: x + 273.15,
                "F": lambda x: (x - 32) * 5/9 + 273.15
            }
        }
        conv = conversions.get(conversion_type, {})
        converter = conv.get(unit)
        return converter(value) if callable(converter) else value * (converter or 0)
    except (ValueError, KeyError, TypeError):
        return 0

def get_value(entry, unit_var, conversion_type="time"):
    """Get and convert a value from an entry widget"""
    return convert_value(entry.get(), unit_var.get(), conversion_type)

def save_parameters_to_file(filepath, entries, units, advanced_entries, polarization_file):
    """Save parameters to JSON file without GUI dependencies"""
    params = {
        "Parameters": {
            param: {
                "value": entry.get(),
                "unit": units[param].get()
            } for param, entry in entries.items()
        },
        "Advanced": {
            param: {
                "value": entry.get(),
                "unit": unit_var.get()
            } for param, (entry, unit_var) in advanced_entries.items()
        },
        "Polarization_Method": polarization_file
    }
    
    with open(filepath, "w") as f:
        json.dump(params, f, indent=4)
    return True

def load_parameters_from_file(filepath):
    """Load parameters from JSON file without GUI dependencies"""
    with open(filepath, "r") as f:
        return json.load(f)

def ensure_default_state_files():
    """Ensure default state configuration files exist"""
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
        states = {
            INITIAL_STATE: ["LOW", "LOW", "LOW", "LOW", "HIGH", "HIGH", "LOW", "LOW"],
            "Injection_State_Start": ["HIGH", "LOW", "LOW", "LOW", "HIGH", "HIGH", "LOW", "LOW"],
            "Degassing": ["LOW", "HIGH", "HIGH", "LOW", "LOW", "LOW", "HIGH", "LOW"],
            "Activation_State_Initial": ["LOW", "LOW", "HIGH", "HIGH", "LOW", "LOW", "HIGH", "LOW"],
            "Activation_State_Final": ["LOW", "LOW", "HIGH", "LOW", "LOW", "LOW", "HIGH", "LOW"],
            "Bubbling_State_Initial": ["LOW", "LOW", "HIGH", "HIGH", "LOW", "LOW", "HIGH", "LOW"],
            "Bubbling_State_Final": ["LOW", "LOW", "HIGH", "HIGH", "HIGH", "LOW", "HIGH", "LOW"],
            "Transfer_Initial": ["LOW", "LOW", "LOW", "LOW", "HIGH", "LOW", "HIGH", "HIGH"],
            "Transfer_Final": ["LOW", "LOW", "LOW", "LOW", "HIGH", "LOW", "HIGH", "LOW"],
            "Recycle": ["HIGH", "LOW", "LOW", "LOW", "HIGH", "LOW", "HIGH", "LOW"]
        }
        for state, dio_values in states.items():
            with open(os.path.join(CONFIG_DIR, f"{state}.json"), "w") as f:
                json.dump({f"DIO{i}": dio_values[i] for i in range(8)}, f, indent=4)

# Initialize state files
try:
    ensure_default_state_files()
except Exception as e:
    print(f"Error creating config directory and files: {e}")
    sys.exit(1)

# ==== END PURE UTILITY FUNCTIONS (no-GUI) ==================
"""
SABRE GUI Panel Modules
"""
